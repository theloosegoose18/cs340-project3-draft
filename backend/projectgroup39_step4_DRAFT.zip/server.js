// server.js (DROP-IN REPLACEMENT)
require("dotenv").config({ path: "local.env" });

console.log("ENV CHECK:", {
    DB_HOST: process.env.DB_HOST,
    DB_USER: process.env.DB_USER,
    DB_NAME: process.env.DB_NAME,
    HAS_PASSWORD: !!process.env.DB_PASSWORD,
});

const express = require("express");
const cors = require("cors");
const db = require("./db-connector");

const app = express();

// -------------------- Middleware
app.use(express.json());

// CORS_ORIGIN="http://localhost:5173,http://classwork.engr.oregonstate.edu:2015"
const allowedOrigins = (process.env.CORS_ORIGIN || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

app.use(
    cors({
        credentials: true,
        origin: function (origin, cb) {
            // allow tools like Postman/no-origin requests
            if (!origin) return cb(null, true);

            // allow if list is empty (dev fallback) OR origin is in list
            if (allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
                return cb(null, true);
            }
            return cb(new Error("Not allowed by CORS: " + origin));
        },
    })
);

const PORT = process.env.PORT ? Number(process.env.PORT) : 2011;

// -------------------- Startup DB ping (for debugging)
(async () => {
    try {
        await db.query("SELECT 1;");
        console.log("DB connection: OK");
    } catch (err) {
        console.error("DB connection: FAILED", err.message || err);
    }
})();

// -------------------- Routes
app.get("/api/health", (req, res) => res.json({ ok: true }));

// RESET (calls your stored procedure)
app.post("/api/reset", async (req, res) => {
    try {
        await db.query("CALL sp_reset_db();");
        res.status(200).json({ ok: true, message: "Database reset complete." });
    } catch (err) {
        console.error("RESET error:", err);
        res.status(500).json({ ok: false, error: err.message || String(err) });
    }
});

// READ: Products
app.get("/api/products", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM Products;");
        res.json(rows);
    } catch (err) {
        console.error("GET /api/products error:", err);
        res.status(500).json({ error: "Failed to fetch Products" });
    }
});

// READ: Inventories
app.get("/api/inventories", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM Inventories;");
        res.json(rows);
    } catch (err) {
        console.error("GET /api/inventories error:", err);
        res.status(500).json({ error: "Failed to fetch Inventories" });
    }
});

// READ: ProductInventories
app.get("/api/product-inventories", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM ProductInventories;");
        res.json(rows);
    } catch (err) {
        console.error("GET /api/product-inventories error:", err);
        res.status(500).json({ error: "Failed to fetch ProductInventories" });
    }
});

// READ: Customers
app.get("/api/customers", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM Customers;");
        res.json(rows);
    } catch (err) {
        console.error("GET /api/customers error:", err);
        res.status(500).json({ error: "Failed to fetch Customers" });
    }
});

// READ: Orders
app.get("/api/orders", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM Orders;");
        res.json(rows);
    } catch (err) {
        console.error("GET /api/orders error:", err);
        res.status(500).json({ error: "Failed to fetch Orders" });
    }
});

// READ: OrderProducts
app.get("/api/order-products", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM OrderProducts;");
        res.json(rows);
    } catch (err) {
        console.error("GET /api/order-products error:", err);
        res.status(500).json({ error: "Failed to fetch OrderProducts" });
    }
});

// ONE CUD: delete a product (used to prove RESET works)
app.delete("/api/products/:id", async (req, res) => {
    const productID = Number(req.params.id);
    if (!Number.isInteger(productID) || productID <= 0) {
        return res.status(400).json({ ok: false, error: "Invalid productID" });
    }

    try {
        const [result] = await db.query(
            "DELETE FROM Products WHERE productID = ?;",
            [productID]
        );
        res.json({ ok: true, affectedRows: result.affectedRows });
    } catch (err) {
        console.error("DELETE /api/products/:id error:", err);
        res.status(500).json({ ok: false, error: err.message || String(err) });
    }
});

// -------------------- Listen
app.listen(PORT, () => {
    console.log(`API listening on http://localhost:${PORT}`);
});

// -------------------- Crash hooks (don’t silently exit)
process.on("uncaughtException", (err) => {
    console.error("Uncaught Exception:", err);
});

process.on("unhandledRejection", (reason) => {
    console.error("Unhandled Rejection:", reason);
});